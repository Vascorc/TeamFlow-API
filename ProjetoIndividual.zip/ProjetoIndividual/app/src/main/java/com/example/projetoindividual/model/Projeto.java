package com.example.projetoindividual.model;

import java.util.List;
import java.io.Serializable;

public class Projeto implements Serializable {
    public String nome;
    public List<Tarefa> tarefas;
    private String estado;

    public Projeto(String nome, List<Tarefa> tarefas) {
        this.nome = nome;
        this.tarefas = tarefas;
        this.estado = calcularEstado(); // define estado inicial
    }

    // Construtor usado quando a informação já vem da base de dados
    public Projeto(String nome, List<Tarefa> tarefas, String estado) {
        this.nome = nome;
        this.tarefas = tarefas;
        this.estado = estado; // mantém o estado que já está na base de dados
    }


    // Calcula o estado com base nas tarefas
    private String calcularEstado() {
        int total = tarefas.size();
        int concluidas = 0;

        for (Tarefa tarefa : tarefas) {
            if (tarefa.concluida) {
                concluidas++;
            }
        }

        if (concluidas == 0) return "Por começar";        // nenhuma concluída
        else if (concluidas < total) return "Em andamento"; // algumas concluídas
        else return "Concluído";                          // todas concluídas
    }

    // Atualiza o estado e guarda
    public void atualizarEstado() {
        this.estado = calcularEstado();
    }

    // Retorna o estado atual (para usar na Activity de detalhes)
    public String getEstado() {
        return estado;
    }

    // Ele apenas devolve o estado atualizado
    public String getStatus() {
        atualizarEstado();
        return estado;
    }

    // Alterar nome do projeto
    public void alterarNome(String novoNome) {
        this.nome = novoNome;
    }

    // Adicionar uma nova tarefa ao projeto
    public void adicionarTarefa(Tarefa tarefa) {
        this.tarefas.add(tarefa);
        atualizarEstado();
    }
}
