package com.example.projetoindividual.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.projetoindividual.model.Projeto;
import com.example.projetoindividual.model.Tarefa;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {

    private DatabaseHelper dbHelper;
    private Context context;

    public ProjetoDAO(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
        try {
            dbHelper.copyDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Projeto> getTodosProjetos() {
        List<Projeto> projetos = new ArrayList<>();
        SQLiteDatabase db = SQLiteDatabase.openDatabase(dbHelper.getDatabasePath(), null, SQLiteDatabase.OPEN_READONLY);

        Cursor cursor = db.rawQuery("SELECT * FROM Projeto", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String nome = cursor.getString(cursor.getColumnIndex("nome"));
                String estado = cursor.getString(cursor.getColumnIndex("estado"));

                List<Tarefa> tarefas = getTarefasDoProjeto(id);
                Projeto projeto = new Projeto(nome, tarefas, estado);
                projetos.add(projeto);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return projetos;
    }

    private List<Tarefa> getTarefasDoProjeto(int projetoId) {
        List<Tarefa> tarefas = new ArrayList<>();
        SQLiteDatabase db = SQLiteDatabase.openDatabase(dbHelper.getDatabasePath(), null, SQLiteDatabase.OPEN_READONLY);

        Cursor cursor = db.rawQuery("SELECT * FROM Tarefa WHERE projeto_id = ?", new String[]{String.valueOf(projetoId)});
        if (cursor.moveToFirst()) {
            do {
                String titulo = cursor.getString(cursor.getColumnIndex("titulo"));
                String dataConclusao = cursor.getString(cursor.getColumnIndex("dataConclusao"));
                boolean concluida = cursor.getInt(cursor.getColumnIndex("concluida")) == 1;

                int idTarefa = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                Tarefa tarefa = new Tarefa(idTarefa, titulo, "", dataConclusao, concluida);
                tarefas.add(tarefa);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return tarefas;
    }
}
