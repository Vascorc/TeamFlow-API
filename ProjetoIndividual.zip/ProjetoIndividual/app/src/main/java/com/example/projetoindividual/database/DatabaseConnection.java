package com.example.projetoindividual.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:sqlserver://10.0.2.2:1433;databaseName=PDM;encrypt=false";
    private static final String USER = "meu_user";
    private static final String PASSWORD = "MinhaSenhaForte123";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
