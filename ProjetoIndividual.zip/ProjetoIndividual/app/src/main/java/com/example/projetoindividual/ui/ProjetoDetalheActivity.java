package com.example.projetoindividual.ui;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetoindividual.R;
import com.example.projetoindividual.database.TarefaDAO;
import com.example.projetoindividual.model.Projeto;
import com.example.projetoindividual.model.Tarefa;

public class ProjetoDetalheActivity extends AppCompatActivity {

    public static final String EXTRA_PROJETO = "extra_projeto";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projeto_detalhe);

        // Habilitar a seta de voltar no ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        LinearLayout containerTarefas = findViewById(R.id.containerTarefas);

        // Receber projeto passado pela HomeFragment
        Projeto projeto = (Projeto) getIntent().getSerializableExtra(EXTRA_PROJETO);

        if (projeto == null || projeto.tarefas == null) {
            finish(); // fecha a Activity se estiver inválido
            return;
        }

        // Definir o título do ActionBar para o nome do projeto
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(projeto.nome);
        }

        // Adicionar dinamicamente as tarefas
        for (Tarefa tarefa : projeto.tarefas) {
            CheckBox checkbox = new CheckBox(this);

            // Somente o título da tarefa
            checkbox.setText(tarefa.titulo);
            checkbox.setChecked(tarefa.concluida);

            // Cor do botão (branco desmarcado, azul marcado)
            int[][] states = new int[][] {
                    new int[] { android.R.attr.state_checked },   // checked
                    new int[] { -android.R.attr.state_checked }   // unchecked
            };

            int[] colors = new int[] {
                    getResources().getColor(R.color.hevy_blue, null), // marcado = azul
                    getResources().getColor(android.R.color.white, null) // desmarcado = branco
            };

            checkbox.setButtonTintList(new android.content.res.ColorStateList(states, colors));

            // Texto do checkbox em branco
            checkbox.setTextColor(getResources().getColor(android.R.color.white, null));

            TarefaDAO tarefaDAO = new TarefaDAO(this);

            checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                tarefa.concluida = isChecked;
                tarefaDAO.atualizarTarefa(tarefa, tarefa.id); // salva no SQLite
                atualizarEstadoProjeto(projeto);
            });


            // Adiciona ao container
            containerTarefas.addView(checkbox);
        }
    }


    private void atualizarEstadoProjeto(Projeto projeto) {
        boolean algumaConcluida = false;

        for (Tarefa t : projeto.tarefas) {
            if (t.concluida) {
                algumaConcluida = true;
                break;
            }
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setSubtitle("Estado: " + projeto.getStatus());
        }

    }


    // Tratar clique na seta de voltar
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
