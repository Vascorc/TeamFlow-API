package com.example.projetoindividual.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.projetoindividual.R;
import com.example.projetoindividual.databinding.FragmentHomeBinding;
import com.example.projetoindividual.database.ProjetoDAO;
import com.example.projetoindividual.model.Projeto;
import com.example.projetoindividual.model.Tarefa;
import com.example.projetoindividual.ui.ProjetoDetalheActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private List<Projeto> listaProjetos;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume(); //chamado semore que a aba é aberta


        binding.containerProjetos.removeAllViews(); // Limpar o layout antigo

        // Carregar projetos da DB
        ProjetoDAO projetoDAO = new ProjetoDAO(getContext());
        listaProjetos = projetoDAO.getTodosProjetos();

        ordenarProjetos(listaProjetos, binding.containerProjetos);
    }

    private void ordenarProjetos(List<Projeto> projetos, LinearLayout layout) {
        // "Em andamento"
        for (Projeto projeto : projetos) {
            if (projeto.getStatus().equals("Em andamento")) {
                adicionarCardProjeto(layout, projeto);
            }
        }

        // "Por começar"
        for (Projeto projeto : projetos) {
            if (projeto.getStatus().equals("Por começar")) {
                adicionarCardProjeto(layout, projeto);
            }
        }
    // os comcluidos apenas vao apareceer mesmo na aba dos projetos

    }

    // Função auxiliar que cria e adiciona o card do projeto
    private void adicionarCardProjeto(LinearLayout layout, Projeto projeto) {
        View card = LayoutInflater.from(getContext())
                .inflate(R.layout.item_projeto, layout, false);

        TextView nome = card.findViewById(R.id.textNomeProjeto);
        TextView status = card.findViewById(R.id.textStatusProjeto);
        TextView dataProjeto = card.findViewById(R.id.textDataProjeto);

        nome.setText(projeto.nome);
        status.setText(projeto.getStatus());

        // Pegar a menor data
        String primeiraData = "";
        for (Tarefa t : projeto.tarefas) {
            if (primeiraData.isEmpty() || t.dataConclusao.compareTo(primeiraData) < 0) {
                primeiraData = t.dataConclusao;
            }
        }

        // Formatar data
        try {
            Date data = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(primeiraData);
            primeiraData = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(data);
        } catch (Exception e) {
            e.printStackTrace();
        }

        dataProjeto.setText("Primeira tarefa até: " + primeiraData);

        // Abrir Activity de detalhe
        card.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), ProjetoDetalheActivity.class);
            intent.putExtra(ProjetoDetalheActivity.EXTRA_PROJETO, projeto);
            startActivity(intent);
        });

        layout.addView(card);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
