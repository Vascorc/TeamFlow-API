package com.example.projetoindividual.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.projetoindividual.model.Tarefa;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO {

    private DatabaseHelper dbHelper;

    public TarefaDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
        try {
            dbHelper.copyDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Tarefa> getTodasTarefas() {
        List<Tarefa> tarefas = new ArrayList<>();
        SQLiteDatabase db = SQLiteDatabase.openDatabase(dbHelper.getDatabasePath(), null, SQLiteDatabase.OPEN_READONLY);

        Cursor cursor = db.rawQuery("SELECT * FROM Tarefa", null);
        if (cursor.moveToFirst()) {
            do {
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow("titulo"));
                String dataConclusao = cursor.getString(cursor.getColumnIndexOrThrow("dataConclusao"));
                boolean concluida = cursor.getInt(cursor.getColumnIndexOrThrow("concluida")) == 1;
                int idTarefa = cursor.getInt(cursor.getColumnIndexOrThrow("id"));

                Tarefa tarefa = new Tarefa(idTarefa, titulo, "", dataConclusao, concluida);                tarefas.add(tarefa);

            } while (cursor.moveToNext());

        }

        cursor.close();
        db.close();
        return tarefas;
    }

    public void atualizarTarefa(Tarefa tarefa, int tarefaId) {
        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                dbHelper.getDatabasePath(),
                null,
                SQLiteDatabase.OPEN_READWRITE
        );

        ContentValues valores = new ContentValues();
        if (tarefa.concluida) {
            valores.put("concluida", 1);
        } else {
            valores.put("concluida", 0);
        }


        db.update("Tarefa", valores, "id = ?", new String[]{String.valueOf(tarefaId)});
        db.close();
    }
}
