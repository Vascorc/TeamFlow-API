package com.example.projetoindividual;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Menu;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetoindividual.databinding.ActivityMainBinding;
import com.example.projetoindividual.database.DatabaseHelper;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);

        // Inicializar DatabaseHelper
        dbHelper = new DatabaseHelper(this);
        try {
            dbHelper.copyDatabase(); // Copia a DB do assets se ainda não existir
        } catch (IOException e) {
            e.printStackTrace();
        }

        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "A testar ligação à BD SQLite...", Snackbar.LENGTH_LONG)
                        .setAction("Action", null)
                        .setAnchorView(R.id.fab).show();

                // 🔹 Testar ligação numa thread separada
                new Thread(() -> testarLigacaoSQLite()).start();
            }
        });

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        // Configuração do Navigation Drawer — apenas Home (ou outras que queres manter)
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home,
                R.id.nav_projetos)  // removi nav_gallery e nav_slideshow
                .setOpenableLayout(drawer)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    // 🔹 Método para testar a ligação à base SQLite
    private void testarLigacaoSQLite() {
        SQLiteDatabase db = SQLiteDatabase.openDatabase(
                dbHelper.getDatabasePath(),
                null,
                SQLiteDatabase.OPEN_READWRITE
        );

        Cursor cursor = db.rawQuery("SELECT * FROM Projeto", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String nome = cursor.getString(cursor.getColumnIndex("nome"));
                String estado = cursor.getString(cursor.getColumnIndex("estado"));
                Log.d("SQLITE_DB", "Projeto: " + nome + " | Estado: " + estado);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
    }
}
