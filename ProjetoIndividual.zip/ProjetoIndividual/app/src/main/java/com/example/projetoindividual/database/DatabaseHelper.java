package com.example.projetoindividual.database;

import android.content.Context;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper {

    private Context context;
    private String DB_NAME = "projeto_app_simples.db";
    private String DB_PATH;

    public DatabaseHelper(Context context) {
        this.context = context;
        DB_PATH = context.getDatabasePath(DB_NAME).getPath();
    }

    // Copia a base de dados de assets para o dispositivo
    public void copyDatabase() throws IOException {
        java.io.File dbFile = new java.io.File(DB_PATH);
        if (!dbFile.exists()) {
            InputStream is = context.getAssets().open(DB_NAME);
            OutputStream os = new FileOutputStream(DB_PATH);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }

            os.flush();
            os.close();
            is.close();
        }
    }

    // Retorna o caminho da base de dados
    public String getDatabasePath() {
        return DB_PATH;
    }
}
