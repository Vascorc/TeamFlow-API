package com.example.projetoindividual.model;
import java.io.Serializable;

public class Tarefa implements Serializable {
    public String titulo;
    public int id;  // novo campo

    public String descricao;
    public String dataConclusao;
    public boolean concluida;

    public Tarefa(int id, String titulo, String descricao, String dataConclusao, boolean concluida) {
        this.id = id;
        this.titulo = titulo;
        this.dataConclusao = dataConclusao;
        this.concluida = concluida;
    }


    // Alterna o status de concluída
    public void marcarConcluida(boolean status) {
        this.concluida = status;
    }

    // Alterar título da tarefa
    public void alterarTitulo(String novoTitulo) {
        this.titulo = novoTitulo;
    }

    // Alterar descrição da tarefa
    public void alterarDescricao(String novaDescricao) {
        this.descricao = novaDescricao;
    }

    // Alterar data de conclusão
    public void alterarDataConclusao(String novaData) {
        this.dataConclusao = novaData;
    }
}
